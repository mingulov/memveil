# SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception

"""Byte-exact mirrors of the native ``lmb_*_v1`` ABI structs.

Each mirror matches the C layout (offsets, sizes, alignment) so Mojo can
build request structs and parse response structs in place. Pointers cross
the boundary as ``UInt64`` addresses; conversion to and from ``Pointer``
happens only at the call boundary in the session wrapper.

``NativeLib`` is the single site of ``extern`` calls: every ``lmb_*``
operation is resolved and invoked here, and every argument is
fixed-width. The session wrapper owns a ``NativeLib`` and never calls
C directly.
"""
from std.ffi import OwnedDLHandle
from std.memory import MutPointer

from libbpf_mojo.error import ENOENT, ENOSYS, LmbError

comptime OP_NONE = UInt32(0)
comptime OP_OPEN = UInt32(1)
comptime OP_LOAD = UInt32(2)
comptime OP_ATTACH = UInt32(3)
comptime OP_POLL = UInt32(4)
comptime OP_MAP_INFO = UInt32(5)
comptime OP_MAP_READ = UInt32(6)
comptime OP_MAP_WRITE = UInt32(7)
comptime OP_STATS = UInt32(8)
comptime OP_DETACH = UInt32(9)
comptime OP_CLOSE = UInt32(10)

comptime DOMAIN_NONE = UInt32(0)
comptime DOMAIN_POSIX = UInt32(1)
comptime DOMAIN_LIBBPF = UInt32(2)
comptime DOMAIN_KERNEL = UInt32(3)
comptime DOMAIN_BRIDGE = UInt32(4)

comptime ATTACH_TRACEPOINT = UInt32(1)
comptime ATTACH_TRACING = UInt32(2)

comptime FRAME_HEADER_SIZE = UInt32(8)
comptime FRAME_VERSION = UInt32(1)
comptime MAX_RAW_BYTES = UInt32(4096)
comptime MAX_FRAME_BYTES = UInt32(4104)


@fieldwise_init
struct BytesV1(Copyable):
    """Mirrors ``struct lmb_bytes_v1``: pointer plus length."""

    var ptr: UInt64
    var len: UInt32
    var _pad: UInt32


@fieldwise_init
struct OptionsV1(Copyable):
    """Mirrors ``struct lmb_options_v1``: session open parameters."""

    var abi_version: UInt32
    var struct_size: UInt32
    var ring: BytesV1
    var max_raw_bytes: UInt32
    var stage_slots: UInt32
    var flags: UInt32
    var _reserved: UInt32


@fieldwise_init
struct AttachV1(Copyable):
    """Mirrors ``struct lmb_attach_v1``: one attach site."""

    var abi_version: UInt32
    var struct_size: UInt32
    var program: BytesV1
    var kind: UInt32
    var flags: UInt32
    var target_a: BytesV1
    var target_b: BytesV1


@fieldwise_init
struct NameV1(Copyable):
    """Mirrors ``struct lmb_name_v1``: a named map lookup key."""

    var abi_version: UInt32
    var struct_size: UInt32
    var name: BytesV1


@fieldwise_init
struct MapInfoV1(Copyable):
    """Mirrors ``struct lmb_map_info_v1``: map geometry for access."""

    var abi_version: UInt32
    var struct_size: UInt32
    var map_type: UInt32
    var key_size: UInt32
    var value_size: UInt32
    var max_entries: UInt32
    var map_flags: UInt32
    var num_cpus: UInt32
    var stride: UInt32
    var _reserved: UInt32


@fieldwise_init
struct StatsV1(Copyable):
    """Mirrors ``struct lmb_stats_v1``: transport counters."""

    var abi_version: UInt32
    var struct_size: UInt32
    var received: UInt64
    var delivered: UInt64
    var staged: UInt64
    var malformed: UInt64
    var dropped: UInt64
    var last_error: Int32
    var _reserved: UInt32


@fieldwise_init
struct ErrorV1(Copyable):
    """Mirrors ``struct lmb_error_v1``: last-error detail record."""

    var abi_version: UInt32
    var struct_size: UInt32
    var operation: UInt32
    var domain: UInt32
    var code: Int32
    var msg_len: UInt32
    var message: Array[UInt8, 1024]


def read_u8_le(p: Pointer[UInt8, _], off: Int) -> UInt32:
    """Load one byte at ``off`` and zero-extend it to ``UInt32``."""
    return UInt32(p.unsafe_offset(off).unsafe_load())


def read_u16_le(p: Pointer[UInt8, _], off: Int) -> UInt32:
    """Load a little-endian ``UInt16`` at ``off``, zero-extended."""
    var base = p.unsafe_offset(off)
    var v = UInt32(base.unsafe_load())
    v |= UInt32(base.unsafe_offset(1).unsafe_load()) << 8
    return v


def read_u32_le(p: Pointer[UInt8, _], off: Int) -> UInt32:
    """Load a little-endian ``UInt32`` at byte offset ``off``."""
    var base = p.unsafe_offset(off)
    var v = UInt32(base.unsafe_load())
    v |= UInt32(base.unsafe_offset(1).unsafe_load()) << 8
    v |= UInt32(base.unsafe_offset(2).unsafe_load()) << 16
    v |= UInt32(base.unsafe_offset(3).unsafe_load()) << 24
    return v


def read_u64_le(p: Pointer[UInt8, _], off: Int) -> UInt64:
    """Load a little-endian ``UInt64`` at byte offset ``off``."""
    var base = p.unsafe_offset(off)
    var v = UInt64(base.unsafe_load())
    v |= UInt64(base.unsafe_offset(1).unsafe_load()) << 8
    v |= UInt64(base.unsafe_offset(2).unsafe_load()) << 16
    v |= UInt64(base.unsafe_offset(3).unsafe_load()) << 24
    v |= UInt64(base.unsafe_offset(4).unsafe_load()) << 32
    v |= UInt64(base.unsafe_offset(5).unsafe_load()) << 40
    v |= UInt64(base.unsafe_offset(6).unsafe_load()) << 48
    v |= UInt64(base.unsafe_offset(7).unsafe_load()) << 56
    return v


struct NativeLib(Movable):
    """Owned native library handle and sole ``extern`` call site.

    Every ``lmb_*`` operation is resolved and invoked by exactly one
    method here. Every pointee argument is a ``Pointer``: passing an
    address as ``UInt64`` loses escape information and the optimizer
    may reorder or drop the pointee stores across the call (observed
    as stale struct contents on Mojo 1.1.0). Only the opaque session
    handle crosses as ``UInt64``; it has no Mojo-side pointee.
    """

    var _handle: OwnedDLHandle

    def __init__(out self, path: String) raises LmbError:
        try:
            self._handle = OwnedDLHandle(path)
        except e:
            raise LmbError(
                OP_OPEN, DOMAIN_BRIDGE, ENOENT, String(e)
            )
        self._require(String("lmb_open"))
        self._require(String("lmb_load"))
        self._require(String("lmb_attach"))
        self._require(String("lmb_poll"))
        self._require(String("lmb_map_info"))
        self._require(String("lmb_map_read"))
        self._require(String("lmb_map_write"))
        self._require(String("lmb_stats"))
        self._require(String("lmb_last_error"))
        self._require(String("lmb_detach"))
        self._require(String("lmb_close"))

    def _require(mut self, name: String) raises LmbError:
        """Resolve one mandatory ABI symbol before any handle exists."""
        try:
            _ = self._handle.get_function[Int32](name)
        except e:
            raise LmbError(
                OP_OPEN, DOMAIN_BRIDGE, ENOSYS,
                String("incomplete native library: ") + name,
            )

    def open_session(
        mut self,
        elf: Pointer[UInt8, _],
        elf_len: UInt64,
        opts: Pointer[OptionsV1, _],
        handle_out: MutPointer[UInt64, _],
    ) raises LmbError -> Int32:
        try:
            var f = self._handle.get_function[Int32](
                String("lmb_open")
            )
            return f(elf, elf_len, opts, handle_out)
        except e:
            raise LmbError(
                OP_OPEN, DOMAIN_BRIDGE, ENOSYS,
                String("unresolved lmb_open"),
            )

    def load(mut self, session: UInt64) raises LmbError -> Int32:
        try:
            var f = self._handle.get_function[Int32](
                String("lmb_load")
            )
            return f(session)
        except e:
            raise LmbError(
                OP_LOAD, DOMAIN_BRIDGE, ENOSYS,
                String("unresolved lmb_load"),
            )

    def attach(
        mut self,
        session: UInt64,
        sites: Pointer[AttachV1, _],
        count: UInt32,
    ) raises LmbError -> Int32:
        try:
            var f = self._handle.get_function[Int32](
                String("lmb_attach")
            )
            return f(session, sites, count)
        except e:
            raise LmbError(
                OP_ATTACH, DOMAIN_BRIDGE, ENOSYS,
                String("unresolved lmb_attach"),
            )

    def poll(
        mut self,
        session: UInt64,
        dst: MutPointer[UInt8, _],
        capacity: UInt32,
        written: MutPointer[UInt32, _],
        required: MutPointer[UInt32, _],
        timeout_ms: Int32,
    ) raises LmbError -> Int32:
        try:
            var f = self._handle.get_function[Int32](
                String("lmb_poll")
            )
            return f(
                session, dst, capacity, written, required,
                timeout_ms,
            )
        except e:
            raise LmbError(
                OP_POLL, DOMAIN_BRIDGE, ENOSYS,
                String("unresolved lmb_poll"),
            )

    def map_info(
        mut self,
        session: UInt64,
        name: Pointer[NameV1, _],
        info_out: MutPointer[MapInfoV1, _],
    ) raises LmbError -> Int32:
        try:
            var f = self._handle.get_function[Int32](
                String("lmb_map_info")
            )
            return f(session, name, info_out)
        except e:
            raise LmbError(
                OP_MAP_INFO, DOMAIN_BRIDGE, ENOSYS,
                String("unresolved lmb_map_info"),
            )

    def map_read(
        mut self,
        session: UInt64,
        name: Pointer[NameV1, _],
        key: Pointer[UInt8, _],
        key_bytes: UInt32,
        dst: MutPointer[UInt8, _],
        capacity: UInt32,
        required: MutPointer[UInt32, _],
    ) raises LmbError -> Int32:
        try:
            var f = self._handle.get_function[Int32](
                String("lmb_map_read")
            )
            return f(
                session, name, key, key_bytes, dst, capacity,
                required,
            )
        except e:
            raise LmbError(
                OP_MAP_READ, DOMAIN_BRIDGE, ENOSYS,
                String("unresolved lmb_map_read"),
            )

    def map_write(
        mut self,
        session: UInt64,
        name: Pointer[NameV1, _],
        key: Pointer[UInt8, _],
        key_bytes: UInt32,
        value: Pointer[UInt8, _],
        value_bytes: UInt32,
    ) raises LmbError -> Int32:
        try:
            var f = self._handle.get_function[Int32](
                String("lmb_map_write")
            )
            return f(
                session, name, key, key_bytes, value, value_bytes,
            )
        except e:
            raise LmbError(
                OP_MAP_WRITE, DOMAIN_BRIDGE, ENOSYS,
                String("unresolved lmb_map_write"),
            )

    def stats(
        mut self,
        session: UInt64,
        stats_out: MutPointer[StatsV1, _],
    ) raises LmbError -> Int32:
        try:
            var f = self._handle.get_function[Int32](
                String("lmb_stats")
            )
            return f(session, stats_out)
        except e:
            raise LmbError(
                OP_STATS, DOMAIN_BRIDGE, ENOSYS,
                String("unresolved lmb_stats"),
            )

    def last_error(
        mut self, err_out: MutPointer[ErrorV1, _]
    ) raises LmbError -> Int32:
        try:
            var f = self._handle.get_function[Int32](
                String("lmb_last_error")
            )
            return f(err_out)
        except e:
            raise LmbError(
                OP_NONE, DOMAIN_BRIDGE, ENOSYS,
                String("unresolved lmb_last_error"),
            )

    def detach(mut self, session: UInt64) raises LmbError -> Int32:
        try:
            var f = self._handle.get_function[Int32](
                String("lmb_detach")
            )
            return f(session)
        except e:
            raise LmbError(
                OP_DETACH, DOMAIN_BRIDGE, ENOSYS,
                String("unresolved lmb_detach"),
            )

    def close_session(
        mut self, session: MutPointer[UInt64, _]
    ) raises LmbError -> Int32:
        try:
            var f = self._handle.get_function[Int32](
                String("lmb_close")
            )
            return f(session)
        except e:
            raise LmbError(
                OP_CLOSE, DOMAIN_BRIDGE, ENOSYS,
                String("unresolved lmb_close"),
            )


# ---------------------------------------------------------------------------
# Generic ABI v1 mirrors (additive; the v1 section above is unchanged).
#
# Byte-exact mirrors of ``native/include/libbpf_mojo_generic.h``. Names
# and map geometry reuse the v1 ``NameV1``/``MapInfoV1`` mirrors above,
# exactly as the C header reuses the v1 structs. Generic symbols are
# optional: ``GenericLib`` only queries presence, and ``NativeLib``
# still requires exactly the eleven v1 operations.
# ---------------------------------------------------------------------------

comptime GENERIC_OP_NONE = UInt32(0)
comptime GENERIC_OP_OBJECT_OPEN = UInt32(1)
comptime GENERIC_OP_PROGRAM_CONFIGURE = UInt32(2)
comptime GENERIC_OP_OBJECT_LOAD = UInt32(3)
comptime GENERIC_OP_PROGRAM_INFO = UInt32(4)
comptime GENERIC_OP_MAP_INFO = UInt32(5)
comptime GENERIC_OP_OBJECT_CLOSE = UInt32(6)
comptime GENERIC_OP_MAP_LOOKUP = UInt32(7)
comptime GENERIC_OP_MAP_UPDATE = UInt32(8)
comptime GENERIC_OP_MAP_DELETE = UInt32(18)
comptime GENERIC_OP_MAP_NEXT_KEY = UInt32(19)
comptime GENERIC_OP_TEST_RUN = UInt32(9)
comptime GENERIC_OP_ATTACH = UInt32(10)
comptime GENERIC_OP_LINK_CLOSE = UInt32(11)
comptime GENERIC_OP_BUFFER_OPEN = UInt32(12)
comptime GENERIC_OP_BUFFER_POLL = UInt32(13)
comptime GENERIC_OP_BUFFER_CLOSE = UInt32(14)
comptime GENERIC_OP_VIEW_REF = UInt32(15)
comptime GENERIC_OP_VIEW_GEN = UInt32(16)
comptime GENERIC_OP_VIEW_CHECK = UInt32(17)
comptime GENERIC_OP_BUFFER_STATS = UInt32(20)

comptime GENERIC_DOMAIN_NONE = UInt32(0)
comptime GENERIC_DOMAIN_POSIX = UInt32(1)
comptime GENERIC_DOMAIN_LIBBPF = UInt32(2)
comptime GENERIC_DOMAIN_KERNEL = UInt32(3)
comptime GENERIC_DOMAIN_BRIDGE = UInt32(4)

comptime ATTACH_FAMILY_TRACEPOINT = UInt32(1)

comptime AUTOLOAD_UNCHANGED = UInt32(0)
comptime AUTOLOAD_ENABLE = UInt32(1)
comptime AUTOLOAD_DISABLE = UInt32(2)

comptime LOG_DISCARD = UInt32(0)
comptime LOG_ON_FAILURE = UInt32(1)
comptime LOG_ALWAYS = UInt32(2)

comptime MAP_UPDATE_ANY = UInt32(0)
comptime MAP_UPDATE_NOEXIST = UInt32(1)
comptime MAP_UPDATE_EXIST = UInt32(2)
comptime MAP_UPDATE_LOCK = UInt32(4)

comptime GENERIC_MAX_LOG_BYTES = UInt64(1048576)
comptime GENERIC_MAX_TEST_BYTES = UInt64(1048576)


@fieldwise_init
struct GenericSpanV1(Copyable):
    """Mirrors ``struct lmb_span_v1``: address plus 64-bit length."""

    var ptr: UInt64
    var len: UInt64


@fieldwise_init
struct GenericOutSpanV1(Copyable):
    """Mirrors ``struct lmb_out_span_v1``: mutable output storage."""

    var ptr: UInt64
    var len: UInt64


@fieldwise_init
struct ObjectOptionsV1(Copyable):
    """Mirrors ``struct lmb_object_options_v1``: object open parameters."""

    var abi_version: UInt32
    var struct_size: UInt32
    var name: GenericSpanV1
    var custom_btf: GenericSpanV1
    var log_level: UInt32
    var flags: UInt32
    var log_capacity: UInt64
    var _reserved: UInt64


@fieldwise_init
struct ProgramOptionsV1(Copyable):
    """Mirrors ``struct lmb_program_options_v1``: pre-load settings."""

    var abi_version: UInt32
    var struct_size: UInt32
    var program: GenericSpanV1
    var attach_target: GenericSpanV1
    var autoload: UInt32
    var flags: UInt32


@fieldwise_init
struct ProgramInfoV1(Copyable):
    """Mirrors ``struct lmb_program_info_v1``: metadata plus log copy-out."""

    var abi_version: UInt32
    var struct_size: UInt32
    var prog_type: UInt32
    var attach_type: UInt32
    var insn_count: UInt64
    var generation: UInt64
    var autoload: UInt32
    var _pad0: UInt32
    var log: GenericOutSpanV1
    var log_actual: UInt64
    var log_truncated: UInt32
    var _reserved: UInt32


@fieldwise_init
struct GenericErrorV1(Copyable):
    """Mirrors ``struct lmb_generic_error_v1``: generic diagnostics."""

    var abi_version: UInt32
    var struct_size: UInt32
    var operation: UInt32
    var domain: UInt32
    var code: Int32
    var msg_len: UInt32
    var message: Array[UInt8, 1024]


@fieldwise_init
struct TestOptionsV1(Copyable):
    """Mirrors ``struct lmb_program_test_options_v1``: test-run inputs."""

    var abi_version: UInt32
    var struct_size: UInt32
    var data_in: GenericSpanV1
    var data_out: GenericOutSpanV1
    var ctx_in: GenericSpanV1
    var ctx_out: GenericOutSpanV1
    var repeat: UInt64
    var flags: UInt64


@fieldwise_init
struct TestResultV1(Copyable):
    """Mirrors ``struct lmb_program_test_result_v1``: test-run outputs."""

    var abi_version: UInt32
    var struct_size: UInt32
    var retval: UInt32
    var _pad: UInt32
    var data_actual: UInt64
    var ctx_actual: UInt64
    var duration_ns: UInt64


@fieldwise_init
struct AttachOptionsV1(Copyable):
    """Mirrors ``struct lmb_attach_options_v1``: one attach request."""

    var abi_version: UInt32
    var struct_size: UInt32
    var program: GenericSpanV1
    var family: UInt32
    var flags: UInt32
    var target_a: GenericSpanV1
    var target_b: GenericSpanV1
    var _reserved: UInt64


@fieldwise_init
struct BufferOptionsV1(Copyable):
    """Mirrors ``struct lmb_buffer_options_v1``: ring buffer parameters."""

    var abi_version: UInt32
    var struct_size: UInt32
    var ring: GenericSpanV1
    var max_raw_bytes: UInt32
    var stage_slots: UInt32
    var flags: UInt32
    var _reserved: UInt32


@fieldwise_init
struct BufferStatsV1(Copyable):
    """Mirrors ``struct lmb_buffer_stats_v1``: transport snapshot."""

    var abi_version: UInt32
    var struct_size: UInt32
    var received: UInt64
    var delivered: UInt64
    var staged: UInt64
    var malformed: UInt64
    var dropped: UInt64


def generic_symbol_names() -> List[String]:
    """The twenty generic ABI symbols in header order."""
    var names = List[String]()
    names.append(String("lmb_object_open_v1"))
    names.append(String("lmb_object_configure_program_v1"))
    names.append(String("lmb_object_load_v1"))
    names.append(String("lmb_object_program_info_v1"))
    names.append(String("lmb_object_map_info_v1"))
    names.append(String("lmb_object_close_v1"))
    names.append(String("lmb_object_release_v1"))
    names.append(String("lmb_generic_last_error_v1"))
    names.append(String("lmb_object_map_lookup_v1"))
    names.append(String("lmb_object_map_update_v1"))
    names.append(String("lmb_program_test_run_v1"))
    names.append(String("lmb_object_attach_v1"))
    names.append(String("lmb_link_close_v1"))
    names.append(String("lmb_buffer_open_v1"))
    names.append(String("lmb_buffer_poll_v1"))
    names.append(String("lmb_buffer_close_v1"))
    names.append(String("lmb_object_ref_v1"))
    names.append(String("lmb_object_unref_v1"))
    names.append(String("lmb_object_gen_v1"))
    names.append(String("lmb_object_gen_check_v1"))
    return names^


struct GenericLib(Movable):
    """Owned native library handle with optional generic resolution.

    Unlike ``NativeLib``, construction requires no symbols: generic
    entry points are never mandatory for v1 consumers. Callers probe
    one symbol at a time with ``has_symbol``, which reports presence
    and never raises.
    """

    var _handle: OwnedDLHandle

    def __init__(out self, path: String) raises LmbError:
        try:
            self._handle = OwnedDLHandle(path)
        except e:
            raise LmbError(
                GENERIC_OP_OBJECT_OPEN, GENERIC_DOMAIN_BRIDGE,
                ENOENT, String(e),
            )

    def has_symbol(mut self, name: String) -> Bool:
        """Report whether ``name`` resolves, without raising."""
        try:
            _ = self._handle.get_function[Int32](name)
            return True
        except e:
            return False

    def require_object(mut self) raises LmbError:
        """Require only the object slice before acquiring an owner."""
        var names = List[String]()
        names.append(String("lmb_object_open_v1"))
        names.append(String("lmb_object_configure_program_v1"))
        names.append(String("lmb_object_load_v1"))
        names.append(String("lmb_object_program_info_v1"))
        names.append(String("lmb_object_map_info_v1"))
        names.append(String("lmb_object_close_v1"))
        names.append(String("lmb_object_release_v1"))
        names.append(String("lmb_generic_last_error_v1"))
        names.append(String("lmb_object_ref_v1"))
        names.append(String("lmb_object_unref_v1"))
        names.append(String("lmb_object_gen_v1"))
        names.append(String("lmb_object_gen_check_v1"))
        for name in names:
            if not self.has_symbol(name.copy()):
                raise LmbError(
                    GENERIC_OP_OBJECT_OPEN,
                    GENERIC_DOMAIN_BRIDGE,
                    ENOSYS,
                    String("incomplete generic object library: ") + name,
                )

    def open_object(
        mut self,
        elf: ImmPointer[UInt8, _],
        elf_len: UInt64,
        opts: ImmPointer[ObjectOptionsV1, _],
        handle_out: MutPointer[UInt64, _],
    ) raises LmbError -> Int32:
        try:
            var f = self._handle.get_function[Int32](
                String("lmb_object_open_v1")
            )
            return f(elf, elf_len, opts, handle_out)
        except e:
            raise LmbError(
                GENERIC_OP_OBJECT_OPEN,
                GENERIC_DOMAIN_BRIDGE,
                ENOSYS,
                String("unresolved lmb_object_open_v1"),
            )

    def require_link(mut self) raises LmbError:
        """Refuse an incomplete owner slice before native acquisition."""
        for name in [String("lmb_object_attach_v1"), String("lmb_link_close_v1")]:
            if not self.has_symbol(name.copy()):
                raise LmbError(GENERIC_OP_ATTACH, GENERIC_DOMAIN_BRIDGE,
                               ENOSYS, "incomplete link library: " + name)

    def require_buffer(mut self) raises LmbError:
        """A ring owner requires open, poll and deterministic teardown."""
        for name in [String("lmb_buffer_open_v1"), String("lmb_buffer_poll_v1"),
                     String("lmb_buffer_close_v1")]:
            if not self.has_symbol(name.copy()):
                raise LmbError(GENERIC_OP_BUFFER_OPEN, GENERIC_DOMAIN_BRIDGE,
                               ENOSYS, "incomplete buffer library: " + name)

    def object_attach(
        mut self, object_handle: UInt64, options: ImmPointer[AttachOptionsV1, _],
        link_out: MutPointer[UInt64, _],
    ) raises LmbError -> Int32:
        try:
            var function = self._handle.get_function[Int32]("lmb_object_attach_v1")
            return function(object_handle, options, link_out)
        except e:
            raise LmbError(GENERIC_OP_ATTACH, GENERIC_DOMAIN_BRIDGE,
                           ENOSYS, "unresolved lmb_object_attach_v1")

    def close_link(mut self, link: MutPointer[UInt64, _]) raises LmbError -> Int32:
        try:
            var function = self._handle.get_function[Int32]("lmb_link_close_v1")
            return function(link)
        except e:
            raise LmbError(GENERIC_OP_LINK_CLOSE, GENERIC_DOMAIN_BRIDGE,
                           ENOSYS, "unresolved lmb_link_close_v1")

    def open_buffer(
        mut self, object_handle: UInt64, options: ImmPointer[BufferOptionsV1, _],
        buffer_out: MutPointer[UInt64, _],
    ) raises LmbError -> Int32:
        try:
            var function = self._handle.get_function[Int32]("lmb_buffer_open_v1")
            return function(object_handle, options, buffer_out)
        except e:
            raise LmbError(GENERIC_OP_BUFFER_OPEN, GENERIC_DOMAIN_BRIDGE,
                           ENOSYS, "unresolved lmb_buffer_open_v1")

    def poll_buffer(
        mut self, buffer: UInt64, destination: MutPointer[UInt8, _],
        capacity: UInt64, timeout_ms: Int32, used: MutPointer[UInt64, _],
        needed: MutPointer[UInt64, _],
    ) raises LmbError -> Int32:
        try:
            var function = self._handle.get_function[Int32]("lmb_buffer_poll_v1")
            return function(buffer, destination, capacity, timeout_ms, used, needed)
        except e:
            raise LmbError(GENERIC_OP_BUFFER_POLL, GENERIC_DOMAIN_BRIDGE,
                           ENOSYS, "unresolved lmb_buffer_poll_v1")

    def close_buffer(mut self, buffer: MutPointer[UInt64, _]) raises LmbError -> Int32:
        try:
            var function = self._handle.get_function[Int32]("lmb_buffer_close_v1")
            return function(buffer)
        except e:
            raise LmbError(GENERIC_OP_BUFFER_CLOSE, GENERIC_DOMAIN_BRIDGE,
                           ENOSYS, "unresolved lmb_buffer_close_v1")

    def buffer_stats(
        mut self, buffer: UInt64, stats_out: MutPointer[BufferStatsV1, _]
    ) raises LmbError -> Int32:
        try:
            var function = self._handle.get_function[Int32]("lmb_buffer_stats_v1")
            return function(buffer, stats_out)
        except e:
            raise LmbError(GENERIC_OP_BUFFER_STATS, GENERIC_DOMAIN_BRIDGE,
                           ENOSYS, "unresolved lmb_buffer_stats_v1")

    def configure_program(
        mut self, object_handle: UInt64, opts: ImmPointer[ProgramOptionsV1, _]
    ) raises LmbError -> Int32:
        try:
            var f = self._handle.get_function[Int32](
                String("lmb_object_configure_program_v1")
            )
            return f(object_handle, opts)
        except e:
            raise LmbError(
                GENERIC_OP_PROGRAM_CONFIGURE,
                GENERIC_DOMAIN_BRIDGE,
                ENOSYS,
                String("unresolved lmb_object_configure_program_v1"),
            )

    def load_object(mut self, object_handle: UInt64) raises LmbError -> Int32:
        try:
            var f = self._handle.get_function[Int32](
                String("lmb_object_load_v1")
            )
            return f(object_handle)
        except e:
            raise LmbError(
                GENERIC_OP_OBJECT_LOAD,
                GENERIC_DOMAIN_BRIDGE,
                ENOSYS,
                String("unresolved lmb_object_load_v1"),
            )

    def program_info(
        mut self,
        object_handle: UInt64,
        name: ImmPointer[NameV1, _],
        result: MutPointer[ProgramInfoV1, _],
    ) raises LmbError -> Int32:
        try:
            var f = self._handle.get_function[Int32](
                String("lmb_object_program_info_v1")
            )
            return f(object_handle, name, result)
        except e:
            raise LmbError(
                GENERIC_OP_PROGRAM_INFO,
                GENERIC_DOMAIN_BRIDGE,
                ENOSYS,
                String("unresolved lmb_object_program_info_v1"),
            )

    def object_map_info(
        mut self,
        object_handle: UInt64,
        name: ImmPointer[NameV1, _],
        result: MutPointer[MapInfoV1, _],
    ) raises LmbError -> Int32:
        try:
            var f = self._handle.get_function[Int32](
                String("lmb_object_map_info_v1")
            )
            return f(object_handle, name, result)
        except e:
            raise LmbError(
                GENERIC_OP_MAP_INFO,
                GENERIC_DOMAIN_BRIDGE,
                ENOSYS,
                String("unresolved lmb_object_map_info_v1"),
            )

    def object_map_lookup(
        mut self,
        object_handle: UInt64,
        name: ImmPointer[NameV1, _],
        key: ImmPointer[UInt8, _], key_bytes: UInt64,
        value: MutPointer[UInt8, _], capacity: UInt64,
        needed: MutPointer[UInt64, _],
    ) raises LmbError -> Int32:
        try:
            var f = self._handle.get_function[Int32]("lmb_object_map_lookup_v1")
            return f(object_handle, name, key, key_bytes, value, capacity, needed)
        except e:
            raise LmbError(GENERIC_OP_MAP_LOOKUP, GENERIC_DOMAIN_BRIDGE,
                           ENOSYS, "unresolved lmb_object_map_lookup_v1")

    def object_map_update(
        mut self,
        object_handle: UInt64,
        name: ImmPointer[NameV1, _],
        key: ImmPointer[UInt8, _], key_bytes: UInt64,
        value: ImmPointer[UInt8, _], value_bytes: UInt64, flags: UInt64,
    ) raises LmbError -> Int32:
        try:
            var f = self._handle.get_function[Int32]("lmb_object_map_update_v1")
            return f(object_handle, name, key, key_bytes, value, value_bytes, flags)
        except e:
            raise LmbError(GENERIC_OP_MAP_UPDATE, GENERIC_DOMAIN_BRIDGE,
                           ENOSYS, "unresolved lmb_object_map_update_v1")

    def object_map_delete(
        mut self, object_handle: UInt64, name: ImmPointer[NameV1, _],
        key: ImmPointer[UInt8, _], key_bytes: UInt64, flags: UInt64,
    ) raises LmbError -> Int32:
        try:
            var f = self._handle.get_function[Int32]("lmb_object_map_delete_v1")
            return f(object_handle, name, key, key_bytes, flags)
        except e:
            raise LmbError(GENERIC_OP_MAP_DELETE, GENERIC_DOMAIN_BRIDGE,
                           ENOSYS, "unresolved lmb_object_map_delete_v1")

    def object_map_next_key(
        mut self, object_handle: UInt64, name: ImmPointer[NameV1, _],
        has_current: UInt32, current: ImmPointer[UInt8, _], current_bytes: UInt64,
        next: MutPointer[UInt8, _], capacity: UInt64, needed: MutPointer[UInt64, _],
    ) raises LmbError -> Int32:
        try:
            var f = self._handle.get_function[Int32]("lmb_object_map_next_key_v1")
            return f(object_handle, name, has_current, current, current_bytes,
                     next, capacity, needed)
        except e:
            raise LmbError(GENERIC_OP_MAP_NEXT_KEY, GENERIC_DOMAIN_BRIDGE,
                           ENOSYS, "unresolved lmb_object_map_next_key_v1")

    def program_test_run(
        mut self,
        object_handle: UInt64,
        name: ImmPointer[NameV1, _],
        options: ImmPointer[TestOptionsV1, _],
        result: MutPointer[TestResultV1, _],
    ) raises LmbError -> Int32:
        try:
            var f = self._handle.get_function[Int32]("lmb_program_test_run_v1")
            return f(object_handle, name, options, result)
        except e:
            raise LmbError(GENERIC_OP_TEST_RUN, GENERIC_DOMAIN_BRIDGE,
                           ENOSYS, "unresolved lmb_program_test_run_v1")

    def close_object(
        mut self, handle: MutPointer[UInt64, _]
    ) raises LmbError -> Int32:
        try:
            var f = self._handle.get_function[Int32](
                String("lmb_object_close_v1")
            )
            return f(handle)
        except e:
            raise LmbError(
                GENERIC_OP_OBJECT_CLOSE,
                GENERIC_DOMAIN_BRIDGE,
                ENOSYS,
                String("unresolved lmb_object_close_v1"),
            )

    def release_object(mut self, handle: MutPointer[UInt64, _]) raises LmbError:
        try:
            var f = self._handle.get_function[NoneType](
                String("lmb_object_release_v1")
            )
            f(handle)
        except e:
            raise LmbError(
                GENERIC_OP_OBJECT_CLOSE,
                GENERIC_DOMAIN_BRIDGE,
                ENOSYS,
                String("unresolved lmb_object_release_v1"),
            )

    def generic_last_error(
        mut self, result: MutPointer[GenericErrorV1, _]
    ) raises LmbError -> Int32:
        try:
            var f = self._handle.get_function[Int32](
                String("lmb_generic_last_error_v1")
            )
            return f(result)
        except e:
            raise LmbError(
                GENERIC_OP_NONE,
                GENERIC_DOMAIN_BRIDGE,
                ENOSYS,
                String("unresolved lmb_generic_last_error_v1"),
            )

    def object_ref(mut self, object_handle: UInt64) raises LmbError -> Int32:
        try:
            var f = self._handle.get_function[Int32](
                String("lmb_object_ref_v1")
            )
            return f(object_handle)
        except e:
            raise LmbError(
                GENERIC_OP_VIEW_REF,
                GENERIC_DOMAIN_BRIDGE,
                ENOSYS,
                String("unresolved lmb_object_ref_v1"),
            )

    def object_unref(mut self, object_handle: UInt64) raises LmbError:
        try:
            var f = self._handle.get_function[NoneType](
                String("lmb_object_unref_v1")
            )
            f(object_handle)
        except e:
            raise LmbError(
                GENERIC_OP_VIEW_REF,
                GENERIC_DOMAIN_BRIDGE,
                ENOSYS,
                String("unresolved lmb_object_unref_v1"),
            )

    def object_generation(
        mut self, object_handle: UInt64, generation: MutPointer[UInt64, _]
    ) raises LmbError -> Int32:
        try:
            var f = self._handle.get_function[Int32](
                String("lmb_object_gen_v1")
            )
            return f(object_handle, generation)
        except e:
            raise LmbError(
                GENERIC_OP_VIEW_GEN,
                GENERIC_DOMAIN_BRIDGE,
                ENOSYS,
                String("unresolved lmb_object_gen_v1"),
            )

    def object_generation_check(
        mut self, object_handle: UInt64, expected: UInt64
    ) raises LmbError -> Int32:
        try:
            var f = self._handle.get_function[Int32](
                String("lmb_object_gen_check_v1")
            )
            return f(object_handle, expected)
        except e:
            raise LmbError(
                GENERIC_OP_VIEW_CHECK,
                GENERIC_DOMAIN_BRIDGE,
                ENOSYS,
                String("unresolved lmb_object_gen_check_v1"),
            )
