# libbpf-mojo 0.2.2

Minimal eBPF collection bridge: Mojo session ownership over a small
C/libbpf ABI, plus a tracepoint example that reconciles 128 real
observations.

## Run the example

No compiler or Pixi is needed. On x86-64-v2 Linux with kernel >= 7.0,
glibc >= 2.38, libelf, and zlib installed, bash >= 5.1 with
coreutils, tracefs mounted at /sys/kernel/tracing, and BPF
privilege (root or equivalent capabilities):

    tar -xzf libbpf-mojo-0.2.2.tar.gz
    cd libbpf-mojo-0.2.2
    ./run-tracepoint.sh

The runner resolves the bridge and runtime libraries from this
directory. It exits 0 with a complete settlement record, 3 on a
short window, 77 without privilege, 1 on failure.

## Layout

- `lib/`: `libbpf_mojo.so.1` (ABI v1) plus bundled Mojo runtime
  libraries. Set `LD_LIBRARY_PATH` to this directory and
  `LMB_NATIVE_LIB` to the bridge when embedding.
- `examples/`: `tracepoint_main` (Mojo collector),
  `reference_consumer` (C consumer of the identical object),
  `tracepoint_trigger` (workload), `probe.bpf.o` (BPF object).
- `include/libbpf_mojo.h`: the native ABI v1 header.
- `mojo/libbpf_mojo/`: importable Mojo wrapper sources. Build
  a consumer with `mojo build -I <package>/mojo`, then run it
  with `LD_LIBRARY_PATH=<package>/lib` and `LMB_NATIVE_LIB`
  pointing at the bridge.
- `licenses/`, `THIRD-PARTY-NOTICES.md`: redistribution notices.
- `LICENSE`, `LICENSES/`: first-party license texts (Apache-2.0 WITH LLVM-exception
  default, including the BPF/userspace wire header; eBPF
  objects GPL-2.0-only; see `MANIFEST.json` `first_party`).
- `MANIFEST.json`: build identities and per-file hashes.

`MANIFEST.json` records the exact bridge, BPF object, binary, and
toolchain identities this package was built from. Verify hashes
before trusting a redistributed copy.
