# libbpf-mojo 0.2.2

Minimal eBPF collection bridge: Mojo session ownership over a small
C/libbpf ABI, plus a tracepoint example that reconciles 128 real
observations. The additive generic object interface opens and configures
ringless ELF objects and provides retained metadata views.

## Use generic objects

Import `Object` from `libbpf_mojo.object` and open caller-provided ELF
bytes with `Object.open`. Object and view ownership are move-only;
views retain the object and its library until they close. Explicit object
close reports BUSY while views exist; release drops the external owner.
Opening and inspecting program metadata need no BPF privilege. Loading
and loaded map metadata require an appropriate runtime environment and
have not been qualified by the host-only ownership tests.

Import byte/scalar lookup and update from `libbpf_mojo.maps`, and
`test_run` and `ProgramTestResult` from `libbpf_mojo.program`.
These functions borrow the retained views and implement checked map
extents and explicit XDP packet/context spans. The scripted host tests
prove the FFI, ownership and rejecting paths. Successful kernel map
access and test-run remain unqualified. See
[maps and test-run](docs/maps-and-test-run.md) for usage and buffer rules.

Import `attach_tracepoint` from `libbpf_mojo.link` and `open_ring`
from `libbpf_mojo.buffer`. Their move-only children retain the original
object/library; buffer polling borrows mutable caller storage and returns
copied diagnostics with u64 sizes. Required close/poll symbols are checked
before acquisition. Host controls exercise the actual pinned reader over
controlled mappings and explicit attachment seams; successful kernel
attachment and event production remain unqualified. See
[links and ring consumers](docs/links-and-ring.md).

Build a consumer with the pinned Mojo 1.2.0 compiler and
`mojo build -I <package>/mojo`. Run the compiled consumer with
`LD_LIBRARY_PATH=<package>/lib` and `LMB_NATIVE_LIB` pointing at
`<package>/lib/libbpf_mojo.so.1`. Compiled consumers use the bundled
runtime libraries without a compiler or Pixi at runtime.

## Run the example

No compiler or Pixi is needed. On x86-64-v2 Linux with kernel >= 7.0,
glibc >= 2.38, libelf, and zlib installed, bash >= 5.1 with
coreutils, tracefs mounted at /sys/kernel/tracing, and BPF
privilege (root or equivalent capabilities):

    tar -xzf libbpf-mojo-0.2.2.tar.gz
    cd libbpf-mojo-0.2.2
    ./run-tracepoint.sh

The runner resolves the bridge and runtime libraries from this
directory. It exits 0 with a complete settlement record, 3 on a
short window, 77 without privilege, 1 on failure.

## Layout

- `lib/`: `libbpf_mojo.so.1` (ABI v1) plus bundled Mojo runtime
  libraries. Set `LD_LIBRARY_PATH` to this directory and
  `LMB_NATIVE_LIB` to the bridge when embedding.
- `examples/`: `tracepoint_main` (Mojo collector),
  `reference_consumer` (C consumer of the identical object),
  `tracepoint_trigger` (workload), `probe.bpf.o` (BPF object).
- `include/libbpf_mojo.h`: the native ABI v1 header.
- `include/libbpf_mojo_generic.h`: the additive generic object ABI
  declarations; object ownership, map lookup/update and XDP test-run
  and explicit tracepoint link/ring ownership are implemented. New generic
  operations resolve optionally, preserving older object/Session libraries.
- `mojo/libbpf_mojo/`: importable Mojo wrapper sources. Build
  a consumer with `mojo build -I <package>/mojo`, then run it
  with `LD_LIBRARY_PATH=<package>/lib` and `LMB_NATIVE_LIB`
  pointing at the bridge.
- `licenses/`, `THIRD-PARTY-NOTICES.md`: redistribution notices.
- `LICENSE`, `LICENSES/`: first-party license texts (Apache-2.0 WITH LLVM-exception
  default, including the BPF/userspace wire header; eBPF
  objects GPL-2.0-only; see `MANIFEST.json` `first_party`).
- `MANIFEST.json`: build identities and per-file hashes.

`MANIFEST.json` records the exact bridge, BPF object, binary, and
toolchain identities this package was built from. Verify hashes
before trusting a redistributed copy.
