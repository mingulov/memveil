# Mojo runtime provenance (libbpf-mojo 0.2.1)

The bundled Mojo runtime libraries ship under
LicenseRef-Modular-Proprietary. The provider
license and third-party notices are staged
alongside this file; redistribution terms come
from the Modular MAX SDK license. Confirm
redistribution before republishing.

- `libAsyncRTRuntimeGlobals.so`, `libKGENCompilerRTShared.so`, `libMSupportGlobals.so` from conda package mojo-compiler 1.1.0 (release):
  https://conda.modular.com/max/linux-64/mojo-compiler-1.1.0-release.conda
  staged license: `licenses/LICENSE.mojo-compiler`
  staged license: `licenses/Third-Party-Notices.mojo-compiler`
