<!-- SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception -->
# libbpf-mojo

Small Mojo interface to libbpf, using one C compatibility layer and clang-built C eBPF objects.

The initial scope is object loading, explicit attachment, bounded event batches, map access, errors, and owned cleanup. MemVeil is the first intended consumer. Application-specific probes, event meanings, correlation, and reporting belong to the application.

Status: 0.2.3 candidate supports ABI v1 (object loading, explicit attachment, bounded event batches, map access, errors, owned cleanup) plus the generic object/link/buffer interface (retained tracepoint links, ring buffers, typed maps, XDP test-run, per-buffer stats snapshots) with importable Mojo wrappers. MemVeil is the first consumer. This is not an upstream libbpf project or a Mojo-to-eBPF compiler.

The additive generic object interface implements ringless ELF open,
named pre-load program configuration, program metadata, retained views
and deterministic ownership. Import `Object`, `ObjectOptions`,
`ProgramView` and `MapView` from `libbpf_mojo.object`; the native contract
is [generic ABI v1](docs/generic-abi-v1.md). Host ownership tests cover
these operations; generic live loading and loaded map metadata still
require target qualification. Native generic map lookup/update are
implemented with checked ordinary/per-CPU extents, exact update flags,
signed diagnostics and lookup copyback only on success. Guarded host
tests exercise parsed BTF objects and the pinned libbpf wrappers without
executing BPF syscalls. Optional retained-map delete and first/next-key calls
preserve exact native errors, full delete flags and owned key results; only matching terminal kernel
ENOENT becomes a typed end marker. Host scripts cover the new ABI and ownership
boundary; successful kernel deletion/traversal remains unqualified.
Native generic program test-run supports the
initial XDP profile with independent packet/context spans, input snapshots
and output copyback only after success and extent checks. Signed native
failures preserve caller outputs and never trigger a retry. Typed Mojo
byte/scalar map calls are in `libbpf_mojo.maps`; explicit test-run and its
copyable result are in `libbpf_mojo.program`. They borrow the existing
retained views and ship in the standalone package. See
[maps and test-run](docs/maps-and-test-run.md) for signatures and buffer
rules. Scripted Mojo tests and installed host consumers establish the
language/ownership boundary; successful kernel map access and test-run
remain unqualified. Native generic tracepoint links and ring consumers now implement the five
remaining operations. Each child retains its object; the ring uses one
copied 4,096-byte slot and returns at most one frame per poll. Guarded host
tests exercise the actual pinned libbpf reader with controlled mappings,
short-buffer retries and exact record conservation. Attachment tests prove
forwarding and ownership through a test seam. Successful kernel attachment
and event production still require live qualification. Move-only `Link` and
`Buffer` owners are available through `libbpf_mojo.link` and
`libbpf_mojo.buffer`, with optional-symbol preflight, copied poll results,
and per-buffer stats snapshots.
See [links and ring consumers](docs/links-and-ring.md) for their signatures,
retention and installed-consumer boundaries.

## Build, test, and package

Pinned Mojo 1.2.0 toolchain via pixi plus system C tooling;
see `docs/build.md` and `toolchain.lock.json`.

    ./tools/build                                    # everything
    ./tools/test --help                              # list suites
    ./tools/test native                              # C contracts
    ./tools/test mojo                                # Mojo ownership
    ./tools/test native --host-only                  # no kernel probes
    ./tools/test mojo --host-only                    # no live-load case
    ./tools/test package-consumer                    # tarball serves a consumer
    LMB_TEST_CONTRACT_BUNDLE=/path/to/data ./tools/test contracts
    ./tools/package                                  # release tarball + MANIFEST

`docs/abi-v1.md` is the normative C boundary contract;
`docs/ownership.md` states lifetimes, errors, and transport in
prose; `docs/support.md` states the tested envelope;
`docs/policy.md` states the evolution and support policy;
`examples/tracepoint/` is a small real collection through the
whole stack. `CONTRIBUTING.md` is the contributor
workflow, `RELEASING.md` the release process,
`SECURITY.md` the vulnerability route, and
`CHANGELOG.md` the version history.

## Licensing

First-party sources are Apache-2.0 WITH LLVM-exception by default
(`LICENSE` plus `LICENSES/LLVM-exception.txt`; per-file
`SPDX-License-Identifier` tags govern). eBPF-only sources
(`examples/tracepoint/probe.bpf.c`,
`tests/fixtures/bpf/ring_test.bpf.c`) are GPL-2.0-only and keep
the kernel `SEC("license") = "GPL"` tag their helpers require;
the wire header shared by BPF and userspace
(`examples/tracepoint/event.h`) carries the default id, whose
exception permits the GPLv2 combination in the built object.
Third-party redistribution notices ship in release tarballs
under `licenses/`, alongside the tarball's
THIRD-PARTY-NOTICES.md.
